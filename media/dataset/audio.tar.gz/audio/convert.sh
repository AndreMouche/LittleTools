#!/bin/bash
sId=1000
for f in ./audio_data/*
do
   echo $f
   curFile=./aac/$sId.aac
   ./ffmpeg -i $f $curFile  
   if [ "$?" == "0" ]; then 
     echo "convert $f to $curFile success" 
     sId=$(($sId+1))
   else
     echo "convert $f to $curFile failed" 
     rm $curFile
   fi
  
   if [ "$sId" == "2000" ]; then
       break;
   fi

done
